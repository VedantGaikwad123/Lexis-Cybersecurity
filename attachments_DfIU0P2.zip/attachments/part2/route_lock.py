import hashlib
import struct
import sys
from pathlib import Path

SEED = b"UNI6CTF|Freedom Chain|Part 2|15-08-1947"


def stream(route_note, length):
    key = hashlib.sha256(SEED + b"|" + route_note.encode()).digest()
    out = bytearray()
    block = 0
    while len(out) < length:
        out.extend(hashlib.sha256(key + b"|" + block.to_bytes(4, "big")).digest())
        block += 1
    return bytes(out[:length])


def ror(value, amount):
    amount &= 7
    return ((value >> amount) | (value << (8 - amount))) & 0xFF


def transform(byte, index, mask, add, rot):
    mixed = (byte ^ mask) & 0xFF
    mixed = (mixed + add + index * 3) & 0xFF
    rot &= 7
    return ((mixed << rot) | (mixed >> (8 - rot))) & 0xFF


def open_blob(path, route_note):
    data = Path(path).read_bytes()
    plain = bytes(a ^ b for a, b in zip(data, stream(route_note, len(data))))
    if plain[:4] != b"FC2!":
        raise SystemExit("route does not open this lock")
    count = plain[4]
    pos = 5
    records = []
    for _ in range(count):
        records.append(struct.unpack("BBBBB", plain[pos:pos + 5]))
        pos += 5
    clue_len = plain[pos]
    pos += 1
    clue = plain[pos:pos + clue_len].decode()
    return records, clue


def main():
    if len(sys.argv) != 4:
        print("15 August Freedom Chain Route Lock")
        print("usage: python route_lock.py sealed_route.bin <route_note> <flag>")
        raise SystemExit(1)
    records, clue = open_blob(sys.argv[1], sys.argv[2])
    candidate = sys.argv[3].encode()
    if len(candidate) != len(records):
        print("wrong")
        return
    for index, mask, add, rot, target in records:
        if transform(candidate[index], index, mask, add, rot) != target:
            print("wrong")
            return
    print("correct")
    print("next_marker:", clue)


if __name__ == "__main__":
    main()
