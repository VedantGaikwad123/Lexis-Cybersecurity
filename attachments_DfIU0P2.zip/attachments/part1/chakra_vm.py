import hashlib
import struct
import sys
from pathlib import Path


def transform(byte, add, xor):
    return ((byte + add) & 0xFF) ^ xor


def stream(key, length):
    out = bytearray()
    block = 0
    while len(out) < length:
        out.extend(hashlib.sha256(key + b"|" + block.to_bytes(4, "big")).digest())
        block += 1
    return bytes(out[:length])


def load_tape(path):
    data = Path(path).read_bytes()
    if data[:5] != b"U6VM1":
        raise SystemExit("invalid parade tape")
    count = data[5]
    pos = 6
    records = []
    for _ in range(count):
        records.append(struct.unpack("BBBB", data[pos:pos + 4]))
        pos += 4
    key_len = data[pos]
    pos += 1
    encrypted_note = data[pos:pos + key_len]
    return records, encrypted_note


def main():
    if len(sys.argv) != 3:
        print("15 August Freedom Chain VM")
        print("usage: python chakra_vm.py parade.tape <flag>")
        raise SystemExit(1)

    records, encrypted_note = load_tape(sys.argv[1])
    candidate = sys.argv[2].encode()
    if len(candidate) != len(records):
        print("wrong")
        return

    for index, add, xor, target in records:
        if transform(candidate[index], add, xor) != target:
            print("wrong")
            return

    key = hashlib.sha256(candidate).digest()
    route_note = bytes(a ^ b for a, b in zip(encrypted_note, stream(key, len(encrypted_note)))).decode()
    print("correct")
    print("route_note:", route_note)


if __name__ == "__main__":
    main()
