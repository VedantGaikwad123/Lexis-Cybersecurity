import hashlib
import sys
from pathlib import Path

SEED = b"UNI6CTF|Freedom Chain|Part 3|15-08-1947"
DECOYS = [
    "UNI6CTF{RedFort_Decoy_Gate_1947}",
    "UNI6CTF{This_VM_Path_Is_False_815}",
    "UNI6CTF{Visible_Flags_Do_Not_End_The_Chain}",
]


def rol(value, amount):
    amount &= 7
    return ((value << amount) | (value >> (8 - amount))) & 0xFF


def stream(marker, length):
    key = hashlib.sha256(SEED + b"|" + marker.encode()).digest()
    out = bytearray()
    block = 0
    while len(out) < length:
        out.extend(hashlib.sha256(key + b"|" + block.to_bytes(4, "big")).digest())
        block += 1
    return bytes(out[:length])


def open_program(path, marker):
    data = Path(path).read_bytes()
    plain = bytes(a ^ b for a, b in zip(data, stream(marker, len(data))))
    if plain[:4] != b"FC3!":
        raise SystemExit("the red fort route is still sealed")
    return plain


def run(program, candidate):
    pc = 4
    expected_len = None
    note = None
    candidate = candidate.encode()
    while pc < len(program):
        op = program[pc]
        pc += 1
        if op == 0x10:
            expected_len = program[pc]
            pc += 1
            if len(candidate) != expected_len:
                return False, note
        elif op == 0x21:
            index, mul, add, xor, rot, target = program[pc:pc + 6]
            pc += 6
            value = (candidate[index] * mul + add + index * 11) & 0xFF
            value ^= xor
            if rol(value, rot) != target:
                return False, note
        elif op == 0x32:
            i, j, lm, rm, add, target = program[pc:pc + 6]
            pc += 6
            if (candidate[i] * lm + candidate[j] * rm + add) & 0xFF != target:
                return False, note
        elif op == 0x43:
            size = program[pc]
            pc += 1
            note = program[pc:pc + size].decode()
            pc += size
        elif op == 0xFF:
            return True, note
        else:
            raise SystemExit("unknown vm opcode")
    return False, note


def main():
    if len(sys.argv) != 4:
        print("15 August Freedom Chain Red Fort VM")
        print("usage: python redfort_vm.py redfort.vm <part2_marker> <flag>")
        raise SystemExit(1)
    program = open_program(sys.argv[1], sys.argv[2])
    ok, note = run(program, sys.argv[3])
    if ok:
        print("correct")
        print("final_note:", note)
    else:
        print("wrong")


if __name__ == "__main__":
    main()
