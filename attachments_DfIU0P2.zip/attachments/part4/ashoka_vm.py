import hashlib
import sys
from pathlib import Path

SEED = b"UNI6CTF|Freedom Chain|Final|15-08-1947"


def rol(value, amount):
    amount &= 7
    return ((value << amount) | (value >> (8 - amount))) & 0xFF


def stream(combined_flags, length):
    key = hashlib.sha256(SEED + b"|" + combined_flags.encode()).digest()
    out = bytearray()
    block = 0
    while len(out) < length:
        out.extend(hashlib.sha256(key + b"|" + block.to_bytes(4, "big")).digest())
        block += 1
    return bytes(out[:length])


def open_program(path, combined_flags):
    data = Path(path).read_bytes()
    plain = bytes(a ^ b for a, b in zip(data, stream(combined_flags, len(data))))
    if plain[:4] != b"FC4!":
        raise SystemExit("the seal is still closed")
    return plain


def run(program, candidate_bytes):
    pc = 4
    expected_len = None
    while pc < len(program):
        op = program[pc]
        pc += 1
        if op == 0x10:
            expected_len = program[pc]
            pc += 1
            if len(candidate_bytes) != expected_len:
                return False
        elif op == 0x21:
            index, mul, add, xor, rot, target = program[pc:pc + 6]
            pc += 6
            value = (candidate_bytes[index] * mul + add + index * 11) & 0xFF
            value ^= xor
            if rol(value, rot) != target:
                return False
        elif op == 0x32:
            i, j, lm, rm, add, target = program[pc:pc + 6]
            pc += 6
            if (candidate_bytes[i] * lm + candidate_bytes[j] * rm + add) & 0xFF != target:
                return False
        elif op == 0x54:
            n = program[pc]
            pc += 1
            idxs = program[pc:pc + n]
            pc += n
            target = program[pc]
            pc += 1
            s = 0
            for idx in idxs:
                s = (s + candidate_bytes[idx]) & 0xFF
            if s != target:
                return False
        elif op == 0x87:
            index, parity, hi, lo = program[pc:pc + 4]
            pc += 4
            target_pc = (hi << 8) | lo
            if (candidate_bytes[index] & 1) == parity:
                pc = target_pc
        elif op == 0x99:
            hi, lo = program[pc:pc + 2]
            pc += 2
            pc = (hi << 8) | lo
        elif op == 0xFF:
            return True
        else:
            raise SystemExit("unknown vm opcode")
    return False


def main():
    if len(sys.argv) != 4:
        print("15 August Freedom Chain - Ashoka Seal (Final)")
        print('usage: python ashoka_vm.py ashoka.seal "FLAG1|FLAG2|FLAG3" <final_flag>')
        raise SystemExit(1)
    program = open_program(sys.argv[1], sys.argv[2])
    ok = run(program, sys.argv[3].encode())
    print("correct" if ok else "wrong")


if __name__ == "__main__":
    main()
