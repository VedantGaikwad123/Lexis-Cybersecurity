# 🚩 CTF Writeup — DIGIT Corp Internal Portal

**Challenge URL:** https://digitalinvestigation.in/CTF/index.html  
**Category:** Web Exploitation / OSINT  


---

## 🎯 Objective

Infiltrate the DIGIT Corp internal portal, bypass the admin authentication gateway, and capture the hidden flag by following a classic web recon attack chain.

---

## Step 1 — Analyzed Landing Page Context / Briefing Guidelines (+15 Pts)

**URL:** `https://digitalinvestigation.in/CTF/index.html`

**Findings:**
- Landing page presents a fictional **"DIGIT Corp — Internal Portal"** in terminal style UI.
- Page status bar: `SYS: ONLINE | SEC: LEVEL 3 | USER: GUEST`
- HTML source contains a comment breadcrumb: `<!-- Step 1 hint — visible on page -->`
- External resources linked: `style.css` and **`script.js`** (key file for later)

**Key Observation:** The challenge is entirely client-side — authentication and flag rendering are controlled by JavaScript/HTML with no backend validation.

### 📸 Screenshot — Landing Page

![Step 1 - DIGIT Corp Landing Page](screenshots/step1_landing_page.jpg)

---

## Step 2 — Inspected Landing Page DOM / Found Crawler Comments (+15 Pts)

**Method:** Browser DevTools → Elements / Sources tab + View Page Source (`Ctrl+U`)

**Finding 1 — HTML comment in `login.html`:**
```html
<!-- EMP_ID: DIGIT2026 -->
```

**Finding 2 — Comment in `script.js`:**
```javascript
// Hint left in plain sight for curious eyes...
// EMP_ID for admin portal: Base64(RElHSVQyMDI2)
```

**Base64 Decode:**
```
RElHSVQyMDI2  →  DIGIT2026
```

**Key Observation:** The credential `DIGIT2026` is leaked in **two places** — an HTML comment AND a Base64-encoded hint inside the JavaScript source file.

### 📸 Screenshot — DevTools showing hidden EMP_ID comment

![Step 2 - DevTools DOM Inspection revealing EMP_ID: DIGIT2026](screenshots/step2_dom_comment.jpg)

---

## Step 3 — Located robots.txt Configuration File (+15 Pts)

**URL:** `https://digitalinvestigation.in/CTF/robots.txt`

**Full Content:**
```
User-agent: *
Disallow: /admin.html

# Nothing to see here...
```

**Key Observation:** `robots.txt` inadvertently exposes the path `/admin.html`. While intended to prevent search engine indexing, it acts as a **free directory map** for any attacker.

### 📸 Screenshot — robots.txt revealing `/admin.html`

![Step 3 - robots.txt disclosing Disallow: /admin.html](screenshots/step3_robots_txt.jpg)

---

## Step 4 — Discovered Restricted Admin Panel Login Page (+15 Pts)

**URL:** `https://digitalinvestigation.in/CTF/admin.html`

**Findings:**
- Direct access shows a blocked terminal view:
  ```
  ⛔ UNAUTHORIZED — You must authenticate first.
  → Go to login.html
  ```
- Page DOM contains **two hidden divs**:
  - `id="blockedView"` → shown when unauthenticated (`display:none`)
  - `id="flagView"` → shown after auth — **already contains the flag!** (`display:none`)

**Key Observation:** The flag is already in the page DOM, just hidden via CSS. This means no server-side protection exists at all.

### 📸 Screenshot — Admin Panel Unauthorized View

![Step 4 - admin.html showing UNAUTHORIZED blocked view](screenshots/step4_admin_blocked.jpg)

---

## Step 5 — Inspected Login DOM / Parsed Hidden EMP_ID Comments (+15 Pts)

**URL:** `https://digitalinvestigation.in/CTF/login.html`

**HTML Source Comment:**
```html
<!-- EMP_ID: DIGIT2026 -->
```

**Login form fields:**
| Field ID | Type | Purpose |
|----------|------|---------|
| `username` | text | Username input |
| `password` | password | Password input |

**Credential confirmed:** `DIGIT2026` (from both HTML comment and script.js Base64 decode)

### 📸 Screenshot — Login Form with Credentials Entered

![Step 5 - Login form at login.html with USERNAME: DIGIT2026 filled in](screenshots/step5_login_form.jpg)

---

## Step 6 — Bypassed Entry Gateway / Admin Dashboard Clearance (+15 Pts)

### Method 1 — Normal Login
1. Navigate to `https://digitalinvestigation.in/CTF/login.html`
2. Enter `Username: admin` | `Password: DIGIT2026`
3. Client-side JavaScript validates → sets session/cookie flag
4. Redirected to `admin.html` with `flagView` div revealed

### Method 2 — Direct DOM Manipulation (Client-Side Bypass)
Since authentication is purely client-side, open the browser console on `admin.html` and run:
```javascript
document.getElementById('blockedView').style.display = 'none';
document.getElementById('flagView').style.display = 'block';
```
This reveals the flag **without any credentials** — proving the auth is entirely cosmetic.

### 📸 Screenshot — 🚩 FLAG CAPTURED on Admin Dashboard

![Step 6 - Admin dashboard reveals the flag after successful authentication](screenshots/step6_flag_captured.jpg)

---

## 🚩 FLAG

```
flag{intern_detective_master}
```

---

## 🔍 Vulnerability Summary

| # | Vulnerability | Location | Severity |
|---|---|---|---|
| 1 | Credential in HTML comment | `login.html` | 🟡 Medium |
| 2 | Credential in JS (Base64 encoded) | `script.js` | 🔴 High |
| 3 | Sensitive path in `robots.txt` | `robots.txt` | 🟡 Medium |
| 4 | Client-side only authentication | `script.js` / `admin.html` | 🔴 Critical |
| 5 | Flag embedded in DOM (hidden by CSS only) | `admin.html` | 🔴 Critical |

---

## 🛡️ Remediation Recommendations

| Issue | Fix |
|-------|-----|
| Credentials in HTML/JS | Never embed secrets in client-side code; use server-side auth |
| `robots.txt` path disclosure | Don't list admin paths; use server-level ACLs instead |
| Client-side authentication | Move all auth validation to the server (session tokens, JWTs) |
| Flag in DOM | Never deliver sensitive data to the client before auth is proven server-side |
| Base64 "obfuscation" | Base64 is encoding, not encryption — it provides zero security |

---

## 🧰 Tools & Techniques Used

| Tool / Technique | Purpose |
|---|---|
| Browser DevTools (Elements) | Inspect DOM, find hidden HTML comments |
| View Page Source (`Ctrl+U`) | Read raw HTML including comments |
| `robots.txt` manual fetch | Discover hidden admin path |
| Base64 decode | Decode `RElHSVQyMDI2` → `DIGIT2026` |
| Direct URL navigation | Access `/admin.html` directly |
| Browser Console JS injection | DOM manipulation bypass without credentials |

---

## 🗺️ Attack Chain Diagram

```
index.html
    │
    ├── View Source → script.js comment → Base64 hint → DIGIT2026
    │
    └── robots.txt → Disallow: /admin.html
                          │
                          └── admin.html → blocked → login.html
                                                          │
                                                          ├── HTML comment → EMP_ID: DIGIT2026
                                                          │
                                                          └── Login: DIGIT2026/DIGIT2026
                                                                        │
                                                                    admin.html
                                                                        │
                                                                  🚩 FLAG{D1G1T_C0RP_PWN3D_2026}
```

---

*Writeup by: CTF Participant | Challenge: DIGIT Corp Internal Portal | Platform: digitalinvestigation.in*
